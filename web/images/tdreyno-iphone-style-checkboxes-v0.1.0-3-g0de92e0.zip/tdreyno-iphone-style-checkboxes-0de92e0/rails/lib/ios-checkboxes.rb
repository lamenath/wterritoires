require "ios-checkboxes/version"

module IOSCheckboxes
  class Engine < ::Rails::Engine
  end
end